# -*- coding: utf-8 -*-
from settings import *

# flask core settings
DEBUG = False
